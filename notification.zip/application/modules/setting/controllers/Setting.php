<?php (defined('BASEPATH')) or exit('No direct script access allowed');

class Setting extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('model_setting');
        $this->load->model('model_invoice');
    }


    public function index()
    {
        $result = !empty($this->model_setting->getPage()->items) ? $this->model_setting->getPage()->items : [];
        $tab = !empty($this->input->get('tab', TRUE)) ? $this->input->get('tab', TRUE) : 'invoice';
        $days = $this->config->item('day');

        $this->data['days'] = [];
        // $dateSelect = $this->input->get('dateSelect') ? $this->input->get('dateSelect') : '';
        $startDate =  date('Y-m-d');
        $endDate =  date('Y-m-d', strtotime("+7 day", strtotime(date('Y-m-d'))));
        // $cus_no =  $this->input->get('customer') ? $this->input->get('endDate') : '';
        $typeSC =  '0281';
        // $is_bill = $this->input->get('is_bill') ? $this->input->get('is_bill') : '3';

        // $condition = (object)[
        //     'dateSelect' => $dateSelect,
        //     'startDate' => $startDate,
        //     'endDate' => $endDate,
        //     'cus_no' => $cus_no,
        //     'type' => $typeSC,
        //     'is_bill' => $is_bill
        // ];

        $o = $this->model_system->getTypeBusiness()->items;
        // var_dump($condition);
        // exit;

        foreach ($o as $v) {
            $this->data['types'][$v->msaleorg] = $v;
        }

        foreach ($days as $day) {
            $this->data['days'][$day->id] = $day;
        }

        // $this->data['page'] = 'Setting';
        $this->data['lists'] = $result;
        $this->data['tab'] = $tab;
        $this->data['page_header'] = 'Setting';
        $this->data['selectDays'] = $this->model_system->getDateSelect()->items;
        $this->data['typeSC'] = $typeSC;
        $this->data['startDate'] = $startDate;
        $this->data['endDate'] = $endDate;
        $this->loadAsset(['dataTables', 'datepicker', 'select2', 'parsley']);
        $this->view('setting_form');
    }

    public function create()
    {
        $list = $this->config->item('page');

        foreach ($list as $page) {
            foreach ($page->colunm as $val) {
                $params = [
                    genRandomString(16),
                    $page->page,
                    $val->name,
                    $val->id,
                    $page->id,
                    1
                ];
                $this->model_setting->create($params);
            }
        }
    }

    public function process($page)
    {
        $output = $this->apiDefaultOutput();
        $params = $this->input->post();
        $result = $this->model_setting->getPage()->items;


        if (!empty($params)) {
            $formData = [];
            if ($page == 'invoice') {
                $formData = $result['invoice'];
            } else if ($page == 'report') {
                $formData = $result['report'];
            } else {
                $formData = $result['customer'];
            }

            foreach ($formData as $val) {
                if (in_array($val->uuid, $params['is_show'])) {
                    $this->model_setting->updateSetting($val->uuid, [1]);
                } else {
                    $this->model_setting->updateSetting($val->uuid, [0]);
                }
            }

            $output['status'] = 200;
            $output['data'] = $params;
        }

        $output['source'] = $params;
        $this->responseJSON($output);
    }

    public function repair()
    {
        $output = $this->apiDefaultOutput();
        $params = $this->input->post();
        $result = $this->model_setting->getInvoice((object)$params)->items;

        // echo '<pre>';
        // var_dump($result);
        // exit;
        // echo '</pre>';
        //$start, $end

        if (!empty($result)) {
            foreach ($result as $key => $res) {
                $uuid = genRandomString(16);
                $data = [
                    $result[$key][0]->msendto,
                    $key,
                    $this->ramdomBillNo($result[$key][0]->msendto),
                    FALSE,
                    date("Y-m-d H:i:s"),
                    $uuid,
                    $params['startDate'],
                    $params['endDate'],
                    FALSE,
                    date("Y-m-d H:i:s"),
                    NULL,
                    NULL
                ];

                $this->model_invoice->createInvoice($data);
                $report = $this->model_invoice->getReportUuid($uuid)->items;
                $reportMain[$key] = $report;

                $genData = [];

                if (!empty($report)) {
                    $genData = $this->genInvoiceDetail($report, $result[$key]);

                    if (empty($genData)) {
                        $output['status'] = 500;
                        $output['msg'] = 'ไม่สามารถสร้างใบแจ้งเตือนได้';
                        $output['error'] = 'ไม่สามารถสร้างใบแจ้งเตือนได้';
                    }
                } else {
                    $output['status'] = 500;
                    $output['msg'] = 'ไม่สามารถสร้างใบแจ้งเตือนได้';
                    $output['error'] = 'ไม่สามารถสร้างใบแจ้งเตือนได้';
                }
            }

            $checkMain = !empty($this->findObjectSendTo($result)) ? true : false;
            foreach ($reportMain as $key => $repor) {
                $email = $this->genEmail((array)$repor, 'invoice', $checkMain);
                if ($email->status == 204) {
                    $output['status'] = 204;
                    $output['data'] = (object)['data' => false, 'msg' => 'No email'];
                } else if ($email->status == 500) {
                    $output['status'] = 500;
                    $output['msg'] = $email->msg;
                    $output['error'] = $email->error;
                }
            }

            $output['status'] = 200;
            $output['data'] = (object)['data' => $reportMain];
        } else {
            $output['status'] = 500;
            $output['msg'] = 'ไม่พบข้อมูลค่าใช้จ่าย';
            $output['error'] = 'ไม่พบข้อมูลค่าใช้จ่าย';
        }

        // echo '<pre>';
        // var_dump($data);
        // exit;
        // echo '</pre>';

        $output['source'] = $params;
        $this->responseJSON($output);
    }

    function findObjectSendTo($data)
    {

        foreach ($data as $element) {
            foreach ($element as $res) {
                if ($res->msendto == $res->mcustno) {
                    return true;
                    break;
                }
            }
        }

        return false;
    }


    public function genInvoiceDetail($report, $lists)
    {
        set_time_limit(0);
        if (!empty($report) && !empty($lists)) {
            foreach ($lists as $res) {
                $data = [
                    genRandomString(16),
                    $report->bill_no,
                    $report->uuid,
                    $res->macctdoc,
                    $res->mcustno,
                    $res->msendto,
                    $res->mdoctype,
                    $res->mbillno,
                    $res->mpostdate,
                    $res->mduedate,
                    $res->msaleorg,
                    $res->mpayterm,
                    $res->mnetamt,
                    $res->mtext,
                    $this->genType($res->mdoctype)
                ];

                $this->model_invoice->createDetailInvoice($data);
            }

            return true;
        }
        return false;
    }
}
