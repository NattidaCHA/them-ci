<?php foreach($lists as $list) { ?>
  <p><?php echo  $list->mcustno ?></p>
  <p><?php echo  $list->mday ?></p>
<?php } ?>